/* ((((((((((((((((((((((((((+=======================================+)))))))))))))))))))))))))) -*/
/* Started globalControlService */
buddingXpert.factory('globalControlService', function() {
	var globalControlService = this;
	globalControlService.url = {
		baseUrlCardDigitalSales : 'buddingXpert/',
		login : 'login',
		logout: 'logout',
		// for Admin
		dashboardCounts : 'services/getDashBoardCounts',
		getJobSeekerResumes : 'getJobSeekerResumes',
		// for Jobseeker
		registeruser : 'services/addJobSeeker',
		getjobseekerDtls : 'getjobseekerDtls',
		updateuser : 'services/updateJobSeeker',
		// For employer
		registeremployer : 'services/addEmployer',
		getEmployerDtls : 'services/getEmployerDtls',
		addJob : 'addJob',
		getJobDtls: 'getJobDtls',
		updateemployer : 'services/updateEmployer',

		// for Form
		getCityList : 'getCity',
		getStateList : 'getState'
	};
	return globalControlService;

});
/* Closed globalControlService */

/* ((((((((((((((((((((((((((+=======================================+)))))))))))))))))))))))))) - */

/* Started applyNowService */
// TODO AJAX service Functions
buddingXpert.factory('applyNowService', function($http, globalControlService) {
	var factory = {};
	factory.tryLogin = function(params) {
		return $http.post(globalControlService.url.login, params);
	};
	factory.logout = function(){
		return $http.post(globalControlService.url.logout);
	}
	factory.tryRegisterUser = function(params) {
		return $http.post(globalControlService.url.registeruser, params);
	};
	factory.tryRegisterEmployer = function(params) {
		return $http.post(globalControlService.url.registeremployer, params);
	};
	factory.getState=function(){ 		
		return  $http.post(globalControlService.url.getStateList);
	};
	factory.getCity=function(params){ 		
		return  $http.post(globalControlService.url.getCityList + "?stateId=" + params ,params);
	};
	return factory;
});
buddingXpert.factory('dashBoardService', function($http, globalControlService) {
	var factory = {};
	//for adminDashBoard
	factory.getDashDetails = function(params) {
		return $http.post(globalControlService.url.dashboardCounts);
	};
	//for employer dashboard
	factory.getEmployerDtls = function(params) {
		return $http.post(globalControlService.url.getEmployerDtls);
	};
	factory.addJob = function(params) {
		return $http.post(globalControlService.url.addJob);
	};
	factory.getJobDtls = function(params) {
		return $http.post(globalControlService.url.getJobDtls);
	};
	factory.updateemployer = function(params) {
		return $http.post(globalControlService.url.updateemployer);
	};

	//for User Dashboard
	factory.getjobseekerDtls = function(params) {
		return $http.post(globalControlService.url.getjobseekerDtls);
	};
	factory.updateuser = function(params) {
		return $http.post(globalControlService.url.updateuser);
	};

	return factory;
});
/* Closed applyNowService */

/* Started localstorageService.js */
buddingXpert.factory('$localstorage', [ '$window', function($window) {
	return {
		set : function(key, value) {
			$window.localStorage[key] = value;
		},
		get : function(key, defaultValue) {
			return $window.localStorage[key] || defaultValue;
		},
		setObject : function(key, value) {
			$window.localStorage[key] = JSON.stringify(value);
		},
		getObject : function(key) {
			return JSON.parse($window.localStorage[key] || '{}');
		},
		clearAll : function() {
			$window.localStorage.clear();
		},
		clearValue : function(key) {
			$window.localStorage[key] = '';
		},
		clearObject : function(key) {
			$window.localStorage[key] = '{}';
		}
	};
} ]);
/* Closed localstorageService.js */

/* ((((((((((((((((((((((((((+=======================================+)))))))))))))))))))))))))) - */

// TODO Controller DATA Builder
function tryLoginFunction($scope, applyNowService, $state, $rootScope, params) {
	var promise = applyNowService.tryLogin(params);
	promise.then(function(response) {
		// TODO yes Response and no response
		response = JSON.parse(JSON.stringify(response.data));
		if (response.page == "failure") {
			$state.go("failure", {
				reason : "login"
			});
		} else {
			// TODO set the page given by the server ;
			// $state.go(response.page);
			$state.go("dashboard");

		}
		/*
		 * if (response.status == true || response.redirect == "dashboard") {
		 *  }
		 */
	}, function(error) {
		console.log(error);
		// TODO if some error
		// TODO redirect to particular page if error n
		$state.go("dashboard");
	});
}

function logout($scope,applyNowService,$state){
	var promise = applyNowService.logout();
	promise.then(function(response){
		response = JSON.parse(JSON.stringify(response.data));
		if(response.data == "success"){
			$state.go("login");
		}
	}
	, function(error){
		//console.log("Some Error");
		$state.go("login");
	});
}

// TODO Controller DATA Builder
/*
 * function tryRegisterFunction($scope, applyNowService, $state, $rootScope,
 * params) { var promise = applyNowService.tryRegisterUser(params);
 * promise.then(function(response) { // TODO yes Response response =
 * JSON.parse(JSON.stringify(response.data)); }, function(error) {
 * console.log(error); // TODO if some error }); }
 */

// TODO Controller DATA Builder
function tryRegisterEmployerFunction($scope, applyNowService, $state,
		$rootScope, params) {
	var promise = applyNowService.tryRegisterEmployer(params);
	promise.then(function(response) {
		// TODO yes Response then go to the edashboard else some error display
		// messagae error
		response = JSON.parse(JSON.stringify(response.data));
		$state.go("edashboard");
	}, function(error) {
		console.log(error);
		// TODO if some error
		$state.go("edashboard");
	});
}

function registerForm(resumeFile, details) {
	var form1 = document.createElement("form");
	form1.setAttribute("method", "POST");
	form1.setAttribute("enctype", "multipart/form-data");
	var detailsField = document.createElement("input");
	detailsField.setAttribute("type", "text");
	detailsField.setAttribute("name", "jobSeekerDetailData");
	detailsField.setAttribute("value", JSON.stringify(details));
	form1.appendChild(resumeFile);
	form1.appendChild(detailsField);
	form1.setAttribute("id", "dummy_form1");
	form1.setAttribute("style", "display:none");
	document.body.appendChild(form1);
	var formObj1 = document.getElementById("dummy_form1");
	formObj1.action = 'services/addJobSeeker';
	formObj1.submit();
}

function getDashDetails($scope, dashBoardService) {
	var promise = dashBoardService.getDashDetails();
	promise.then(function(response) {
		response = response.data;
		$scope.jobseekerCount = response.jobSeekersCount;
		$scope.employersCount = response.employeersCount;
		$scope.jobsCount = response.jobsCount;
		$scope.user = response.username;
	}, function(error) {
		console.log(error);
		// TODO if some error
	});
}








function getStateID(list,passedList,$scope){
	for(var i=0;i<list.length;i++){
	if(list[i]["statename"]==passedList[statename]){
		$scope.stateIDCalc=list[i]["stateId"];
		break;
		}
	}
}

function getCity($scope, applyNowService,params) {
	var promise = applyNowService.getCity(params);
	promise.then(function(response) {
		response= JSON.parse(JSON.stringify(response.data));
		if (response.data != ""){
			$scope.citylist=[];
			$scope.citylist= response;
			$scope.citylistOriginal=response;
		 	}
	}, function(error) {
		console.log("Some error occured in fetching city list")
	});
}
function getState($scope, applyNowService,passedList,code) {	
	var promise = applyNowService.getState();
	promise.then(function(response) {
		response= JSON.parse(JSON.stringify(response.data));
		if (response!= ""){
			$scope.statedata= response;
			$scope.stateOriginal = response;
			if(code){
				getStateID($scope.statedata,passedList,$scope);
				getCity($scope, applyNowService,$scope.stateIDCalc);				
			}			
		}			
		else 
			$scope.statedata=[];
		
	}, function(error) {
		$scope.statedata=[];
	});
	
}


function searchstatecity(nameKey, myArray,typesearch){
	if(typesearch == "state")
	{$scope.statedata=[];
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i].statename.includes(nameKey)) {
            $scope.statedata.push({statename: $scope.stateOriginal[i].statename, stateId : $scope.stateOriginal[i].stateId});
        }
    }
	}
	if(typesearch == "city")
	{$scope.citylist=[];
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i].cityname.includes(nameKey)) {
            $scope.citylist.push({cityname: $scope.citylistOriginal[i].cityname, cityid : $scope.citylistOriginal[i].cityid});
        }
    }
		
	}
}
