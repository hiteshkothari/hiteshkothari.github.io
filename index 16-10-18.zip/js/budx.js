/*Started js/app.js*/

var buddingXpert = angular.module('buddingXpert', [ 'ui.router' ]);
buddingXpert.config(function($stateProvider, $urlRouterProvider,
		$sceDelegateProvider) {
	// TODO add employee dashboard and user dashboard statess
	$sceDelegateProvider.resourceUrlWhitelist([ 'self', 'css/img/**',
			'partials/**', 'https://fonts.gstatic.com/' ]);
	$urlRouterProvider.otherwise('/');
	$stateProvider.state('home', {
		url : '/',
		controller : 'homeController',
		templateUrl : 'partials/home/home.html'
	}).state('login', {
		url : '/login',
		controller : 'loginController',
		templateUrl : 'partials/login_signup.html',
		params:{page:""}
	}).state('dashboard', {
		url : '/dashboard',
		templateUrl : 'partials/dashboard/dashboard.html',
		controller : 'dashboardController'
	}).state('udashboard', {
		url : '/udashboard',
		templateUrl : 'partials/dashboard/userdashboard.html',
		controller : 'udashboardController'
	}).state('edashboard', {
		url : '/edashboard',
		templateUrl : 'partials/dashboard/employerdashboard.html',
		controller : 'edashboardController'
	}).state('failure', {
		url : '/failure',
		templateUrl : 'partials/problem/someerror.html',
		controller : 'someerrorController'
	})/*.state('applynow', {
		url : '/applynow',
		templateUrl : 'partials/ApplyNow/resumeform.html',
		controller : 'applyNowController',
		params : {
			seeker : ""
		}
	}).state('nav', {
		url : '/nav',
		templateUrl : 'partials/navbar.html',
		controller : 'applyNowController'
	})*/;
});
/* Closed js/app.js */

// Controllers and their Functions
buddingXpert.controller("homeController", homeController);
buddingXpert.controller("loginController", loginController);
/*buddingXpert.controller("applyNowController", applyNowController);*/
buddingXpert.controller("dashboardController", dashboardController);
buddingXpert.controller("edashboardController", edashboardController);
buddingXpert.controller("udashboardController", udashboardController);
buddingXpert.controller("someerrorController", someerrorController);

function homeController($scope, $state) {
	$scope.goLoginNow = function(whereToGo){
		$state.go('login', {page:whereToGo});
	};
	$scope.navPanelVisible=false;
	$scope.showsidenav= function(){$scope.navPanelVisible = true;};
	$scope.hidesidenav= function(){$scope.navPanelVisible = false;};
};

function loginController($scope, applyNowService, $rootScope, $stateParams ,$state) {
	$scope.loginFormData = {};
	$scope.fresherFormData={};
	$scope.experiencedFormData={};
	$scope.employerFormData={};
	getState($scope,applyNowService,passedList,false);
	
	$scope.stateBox = false;
	$scope.cityBox = false;
	$scope.stateList = [];
	$scope.cityList = [ {
		cityName : 'mumbai'
	}, {
		cityName : 'masas'
	} ];
	$scope.showStateOptions = false;
	$scope.showCityOptions = false;
	
	// Which Form to display
	var pageTodisplay = $stateParams.page;
	console.log(pageTodisplay);
	if (pageTodisplay == "jobseeker") {
		
		$scope.loginForm = false;
		$scope.fresher=true;
		$scope.seeker=true;
	}else if(pageTodisplay =="employer"){
		
		$scope.loginForm = false;
		$scope.seeker=false;
	}else{
		$scope.loginForm = true;
		$scope.seeker=true;
		$scope.fresher=true;
		
	}
	$scope.register = function(registrationType){
		
	if(registrationType == 'jobseeker'){
			var fileInput = document.getElementById("resumeUpload");
			//$scope.fresherFormData.registrationUserType="fresher";
			$scope.fresherFormData.yearsofexperience = 0 ;
			registerForm(fileInput ,$scope.fresherFormData);
			//var params = {resumeFile : fileInput.files[0] ,jobSeekerDetailData: $scope.fresherFormData};
			//tryRegisterFunction($scope, applyNowService, $state, $rootScope, params);	
		}
		if(registrationType == 'experienced'){
			var fileInput = document.getElementById("resumeUpload");
			//$scope.experiencedFormData.registrationUserType="experienced";
			registerForm(fileInput ,$scope.experiencedFormData);
			/*var params = {resumeFile : fileInput.files[0] ,jobSeekerDetailData: $scope.experiencedFormData};*/
			/*tryRegisterFunction($scope, applyNowService, $state, $rootScope, params);*/	
		}
		if(registrationType == "employer"){
			//var params = {employerDetailData: $scope.employerFormData};
			var params = JSON.stringify($scope.employerFormData);
			tryRegisterEmployerFunction($scope, applyNowService, $state, $rootScope, params);	
		}
		//$state.go("dashboard");
	};
	$scope.login = function(form) {
		/*form.requestType = "login";*/
		var params = form;
		tryLoginFunction($scope, applyNowService, $state, $rootScope, params);
	};
	
	
	
	
	
	
	
	
	
	
	

	$scope.Statetest = "";
	$scope.stateOriginal = [];
	$scope.Citytest = "";
	$scope.citylistOriginal = [];
	$scope.stateerror = false;
	$scope.cityerror = false;
	$scope.isCityPresentFlag = false;
	$scope.iscityActiveFlag = false;
// XXX	This passed list if for state prefilled
	    var passedList={"customer_state": ""};
	    // XXX change tru or false for prefilled and no prefilled data
	    
	
	    $scope.stateIDCalc="";
	    $scope.statedata=[];
		$scope.citylist=[];
		
		
	$scope.myFunction=function(){
    	var statenamed;
    	for (statenamed in $scope.stateOriginal) {
    		if($scope.stateOriginal[statenamed].statename != $scope.Statetest)
    			{$scope.citylist=[];
    			$scope.citylistOriginal=[];
    			$scope.Citytest="";
    			}
    	}
    	$scope.isCityPresentFlag=false;
    	var d= document.getElementById("myDropdown");
    	//console.log($scope.Statetest.length);
    	if($scope.Statetest.length > 2)
    	{
    		searchstatecity($scope.Statetest.toUpperCase(),$scope.stateOriginal,"state");
    		if(d.classList.contains("show") == false)
    		d.classList.toggle("show");
    		
    		
    	}
    	if($scope.Statetest.length < 3){
    		if(d.classList.contains("show") == true)
	    		d.classList.toggle("show");
	    
    	}
    };
    
    $scope.myFunctionCity=function(){
      	var statenamed;
      	var matchfoundState=false;
    	for (statenamed in $scope.stateOriginal) {
    		if($scope.stateOriginal[statenamed].statename.toUpperCase() == $scope.Statetest)
    		{
    			matchfoundState = true;
    			break;
    		}
    	}
    	if(matchfoundState == true){
    		
    	
    	var matchfoundCity=false;
    	var citynamed;
    	for (citynamed in $scope.citylistOriginal) {
    		if($scope.citylistOriginal[citynamed].cityname.toUpperCase() == $scope.Citytest)
    			{
    			matchfoundCity=true;
    			break;
    			}
    		else{
    			matchfoundCity=false;
    		}
    	}
    	if(matchfoundCity == false)
    	{
    		$scope.isCityPresentFlag=false;
    	}
    	if($scope.Statetest != ""){
    	if(!($scope.fresherFormData.state=='')){
    		if(!($scope.fresherFormData.state == undefined)){
    			
    		var dc = document.getElementById("myDropdownCity");
    		if($scope.Citytest.length > 2)
	    	{
	    		if(dc.classList.contains("show") == false)
	    			dc.classList.toggle("show");
	    		searchstatecity($scope.Citytest.toUpperCase(),$scope.citylistOriginal,"city");
	    	}
	    	if($scope.Citytest.length < 3){
	    		if(dc.classList.contains("show") == true)
	    			dc.classList.toggle("show");			    
	    	}
    			
    		}
    		}
    	}else{
    		$scope.citylist=[];
    	}
    	}
    	else{
    		$scope.stateerror=true;
    	}
    }
    $scope.CallCitySelected=function(citySelected){
    	$scope.fresherFormData.resCity = citySelected;
    	$scope.Citytest=citySelected;
    	$scope.cityerror=false;
    	$scope.isCityPresentFlag=true;
	}
    $scope.showStateSelected=function(state){
    	$scope.fresherFormData.state = state;
    	$scope.Statetest=state;
    	$scope.stateerror= false;
    	$scope.isCityPresentFlag=false;
    	$scope.Citytest="";
    	$scope.citylist=[];
    	if(state !=undefined){
			var passedList={"customer_state": state};
			getStateID($scope.statedata,passedList,$scope);
			$scope.iscityActiveFlag=true;
			getCity($scope, applyNowService,$scope.stateIDCalc);		
    	}	
    }
    
    
    
	
};
/*
function applyNowController($scope, $stateParams, $state) {
	// FOR Dialog Box
	$scope.showDialog = true;
	$scope.goToState = {
		outer : 'yes',
		state : 'login'
	};
	$scope.someError = "No error";
	$scope.dialogHeader = "Info!";
	$scope.dialogBody = "Please Login (or Sign up) first so that you can track your Application request!";
	$scope.dialogOkButtonText = "Ok";
	$scope.okButtonDis = true;
	$scope.CancelButtonDis = true;
	$scope.dialogCancelButtonText = "Cancel";
	$scope.dialogCancelButtonClick = function() {
		$scope.showDialog = false;
	};
	$scope.dialogOkButtonClick = function(goTo, someError) {
		if (goTo.outer == "yes") {
			// Means There is a redirect
			$state.go(goTo.state);
		} else {
			// Do some Thing for Error
			console.log("some errror " + $scope.someError);
		}
		$scope.showDialog = false;
	};
};*/
function dashboardController($scope, dashBoardService, applyNowService,$state) {
	console.log("Form dashboard");
	getDashDetails($scope, dashBoardService);
	
	$scope.dologout=function(){
		logout($scope, applyNowService, $state);
	}
	
	
	$scope.navPanelVisible=false;
	$scope.showsidenav= function(){$scope.navPanelVisible = true;};
	$scope.hidesidenav= function(){$scope.navPanelVisible = false;};


};

function edashboardController($scope, applyNowService, $state) {

	$scope.navPanelVisible=false;
	$scope.showsidenav= function(){$scope.navPanelVisible = true;};
	$scope.hidesidenav= function(){$scope.navPanelVisible = false;};

	console.log("Form edashboard");
	$scope.dologout=function(){
		logout($scope, applyNowService, $state);
	}
};

function udashboardController($scope, applyNowService, $state) {

	$scope.navPanelVisible=false;
	$scope.showsidenav= function(){$scope.navPanelVisible = true;};
	$scope.hidesidenav= function(){$scope.navPanelVisible = false;};

	console.log("Form udashboard");
	//displaySettingsPage();
	$scope.dologout=function(){
		logout($scope, applyNowService, $state);
	}
};
function someerrorController($scope, $stateParams){
console.log("reached Failure page ");	
var reason = $stateParams.reason;
if(reason =="login"){
	//TODO failue login
	}
else if(reason=="session"){
	//TODO failue  session expired 
	}
else{
	//TODO some error occured please try again later
}
};




function open_rightSideDrawer() {
	var mySidebar = document.getElementById("mySidebar");
	var overlayBg = document.getElementById("myOverlay");
	if (mySidebar.style.display === 'block') {
		mySidebar.style.display = 'none';
		overlayBg.style.display = "none";
	} else {
		mySidebar.style.display = 'block';
		overlayBg.style.display = "block";
	}
}
function close_rightSideDrawer() {
	var mySidebar = document.getElementById("mySidebar");
	var overlayBg = document.getElementById("myOverlay");
	mySidebar.style.display = "none";
	overlayBg.style.display = "none";
}