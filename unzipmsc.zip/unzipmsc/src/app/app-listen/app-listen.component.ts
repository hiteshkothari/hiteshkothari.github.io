import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listen',
  templateUrl: './app-listen.component.html',
  styleUrls: ['./app-listen.component.css']
})
export class AppListenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
