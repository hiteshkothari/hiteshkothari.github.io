// import { Component } from '@angular/core';
import { Component } from '@angular/core';
@Component({
  selector: 'hello',
  template: `<h1>Speech Sysnthesis using browser  and Face detection using browser </h1>
  Welcome 
   `,
  
  styles: [`h1 { font-family: Lato; }
  // <a [routerLink]="['first']" >First </a>
    <button [routerLink]="['first']"  >Next</button>
  `]
})
export class HelloComponent {
  // @Input() name: string;
  // FFirst 



}



// <table class="w3-table">
// <tr>   <th>Pages </th><th>Content</th>  </tr>
// <tr>   <td>Home  </td><td>Index(This page) </td> </tr> 
// <tr>   <td>First  </td><td> Speech Recognition -STT </td> </tr> 
// <tr>   <td>Second  </td><td> Speech Recognized Color changer  </td> </tr> 
// <tr>   <td>Third  </td><td>Speech Systhesis -TTS using textbox</td> </tr> 
// <tr>   <td>Fourth  </td><td>Face Detection </td> </tr> 
// <tr>   <td>Fifth  </td><td>Weloming the user (Speech Synthesis using detected Face )</td> </tr> 
// <tr>   <td>Sixth  </td><td>Creating Elements using Speech  </td> </tr> 
// <tr>   <td>Seventh  </td><td> Whole Together </td> </tr> 
// <tr>   <td>Seventh  </td><td> Future Scope -- Cretae Website using Speech  while giving users option to select by asking theem  </td> </tr> 

// </table>