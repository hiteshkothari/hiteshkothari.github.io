import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eighth',
  templateUrl: './eighth.component.html',
  styleUrls: ['./eighth.component.css']
})
export class EighthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
